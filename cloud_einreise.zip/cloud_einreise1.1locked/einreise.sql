ALTER TABLE users
ADD einreise INT(11);