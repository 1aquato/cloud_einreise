Config = {} 

------------- Koordinaten ---------------
Config.ReleaseCoordsX = -1037.8014
Config.ReleaseCoordsY = -2737.9597
Config.ReleaseCoordsZ = 20.1693

Config.EinreiseCoordsX = -1141.7408
Config.EinreiseCoordsY = -2794.7341
Config.EinreiseCoordsZ =  27.7087

Config.AdminEinreiseCoordsX = -1106.8346
Config.AdminEinreiseCoordsY = -2811.7920
Config.AdminEinreiseCoordsZ = 27.7087

Config.Range = 100.9
------------- Koordinaten ---------------

------------------------ Einreise Nachrichten ------------------------
Config.NoPermissions = "Dazu hast du kein Rechte!"
Config.EinreiseVerlassen = "Du darfst die Einreise nicht verlassen!"
Config.Einreisebestanden = "Du hast die Einreise bestanden!\nViel Spass!"
Config.AusreiseErfolgreich = "Du wurdest ausgereist! Sprich mit einem Einreisebeamten."
------------------------ Einreise Nachrichten ------------------------

------------------------ Einreise Commands ------------------------
Config.Einreise = "einreise"
Config.Ausreise = "ausreise"
Config.rein = "rein"
Config.raus = "raus"
------------------------ Einreise Commands ------------------------
